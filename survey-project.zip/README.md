Evan Trinh
SE 310
Homework 2 Part B

- All sample serialized files (.ser) are located in the `survey_data` directory in the project.
- Please ensure the driver is ran from the project root directory. This is how IntelliJ would run it and ensures the serialized files are created with the correct relative paths.